from __future__ import annotations

import json
import os
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

import requests

from config import settings
from services.canonical_document_service import (
    CanonicalBlock,
    CanonicalDocument,
    CanonicalPage,
    build_document,
)
from services.chunk_quality_audit_service import looks_like_heading
from services.pdf_classifier_service import PdfClassifierResult


def _normalize_bbox(bbox: Any) -> Optional[Dict[str, float]]:
    if bbox is None:
        return None
    if isinstance(bbox, (list, tuple)) and len(bbox) >= 4:
        return {
            "x0": float(bbox[0]),
            "y0": float(bbox[1]),
            "x1": float(bbox[2]),
            "y1": float(bbox[3]),
        }
    if isinstance(bbox, dict):
        return {
            "x0": float(bbox.get("x0", 0.0) or 0.0),
            "y0": float(bbox.get("y0", 0.0) or 0.0),
            "x1": float(bbox.get("x1", 0.0) or 0.0),
            "y1": float(bbox.get("y1", 0.0) or 0.0),
        }
    return None


def _detect_block_type(text: str) -> str:
    value = str(text or "").strip()
    if not value:
        return "body"
    lowered = value.lower()
    if looks_like_heading(value):
        return "heading"
    if value.startswith((">", '"', "'")):
        return "quote"
    if "\t" in value or ("  " in value and any(ch.isdigit() for ch in value)):
        return "table"
    if lowered.startswith(("dipnot", "footnote")) or (value[:2].isdigit() and len(value.split()) <= 16):
        return "footnote"
    return "body"


class BasePdfAdapter(ABC):
    parser_engine = "UNKNOWN"
    parser_version = "v1"

    @abstractmethod
    def parse(
        self,
        *,
        pdf_path: str,
        document_id: str,
        route: str,
        classifier_result: PdfClassifierResult,
    ) -> CanonicalDocument:
        raise NotImplementedError


class PyMuPdfAdapter(BasePdfAdapter):
    parser_engine = "PYMUPDF"
    parser_version = "v1"

    def parse(
        self,
        *,
        pdf_path: str,
        document_id: str,
        route: str,
        classifier_result: PdfClassifierResult,
    ) -> CanonicalDocument:
        try:
            import fitz  # type: ignore
        except Exception as exc:  # pragma: no cover - optional dependency
            raise RuntimeError("PyMuPDF is required for TEXT_NATIVE parsing") from exc

        source = fitz.open(pdf_path)
        blocks: List[CanonicalBlock] = []
        pages: List[CanonicalPage] = []
        current_heading_path: List[str] = []
        reading_order = 0

        for page_idx in range(len(source)):
            page = source.load_page(page_idx)
            page_metrics = classifier_result.pages[page_idx]
            pages.append(
                CanonicalPage(
                    page_number=page_idx + 1,
                    has_text_layer=bool(page_metrics.has_text_layer),
                    char_count=int(page_metrics.char_count),
                    word_count=int(page_metrics.word_count),
                    ocr_applied=False,
                    image_heavy_suspected=bool(page_metrics.image_heavy_suspected),
                    garbled_ratio=float(page_metrics.garbled_ratio),
                )
            )
            for block_idx, block in enumerate(page.get_text("blocks", sort=True) or []):
                text = str(block[4] or "").strip()
                if not text:
                    continue
                block_type = _detect_block_type(text)
                if block_type == "heading":
                    current_heading_path = [text]
                canonical = CanonicalBlock(
                    block_id=f"{document_id}:p{page_idx + 1}:b{block_idx}",
                    page_number=page_idx + 1,
                    block_type=block_type,
                    text=text,
                    bbox=_normalize_bbox(block[:4]),
                    reading_order=reading_order,
                    heading_path=list(current_heading_path),
                    confidence=1.0,
                    source_engine=self.parser_engine,
                )
                reading_order += 1
                blocks.append(canonical)

        return build_document(
            document_id=document_id,
            route=route,
            parser_engine=self.parser_engine,
            parser_version=self.parser_version,
            pages=pages,
            blocks=blocks,
            classifier_metrics=classifier_result.classifier_metrics,
        )


class LlamaParseAdapter(BasePdfAdapter):
    parser_engine = "LLAMAPARSE"
    parser_version = "v1"

    def parse(
        self,
        *,
        pdf_path: str,
        document_id: str,
        route: str,
        classifier_result: PdfClassifierResult,
    ) -> CanonicalDocument:
        api_key = str(getattr(settings, "LLAMA_CLOUD_API_KEY", "") or "").strip()
        if not api_key:
            raise RuntimeError("LLAMA_CLOUD_API_KEY is required for IMAGE_SCAN parsing")

        upload_url = str(
            getattr(settings, "LLAMA_PARSE_API_URL", "https://api.cloud.llamaindex.ai/api/parsing/upload")
        ).strip()
        result_url_template = str(
            getattr(settings, "LLAMA_PARSE_RESULT_URL_TEMPLATE", "https://api.cloud.llamaindex.ai/api/parsing/job/{job_id}/result/json")
        ).strip()
        timeout_sec = int(getattr(settings, "LLAMA_PARSE_TIMEOUT_SEC", 900))
        poll_interval_sec = int(getattr(settings, "LLAMA_PARSE_POLL_INTERVAL_SEC", 8))
        language = str(getattr(settings, "PDF_OCR_LANGUAGES", "tr,en") or "tr,en")

        with open(pdf_path, "rb") as handle:
            response = requests.post(
                upload_url,
                headers={"Authorization": f"Bearer {api_key}"},
                data={
                    "language": language,
                    "extract_layout": "true",
                    "spatial_text": "true",
                    "preserve_layout_alignment_across_pages": "true",
                },
                files={"file": (os.path.basename(pdf_path), handle, "application/pdf")},
                timeout=120,
            )
        response.raise_for_status()
        payload = response.json()
        job_id = str(payload.get("id") or payload.get("job_id") or "")
        if not job_id:
            raise RuntimeError("LlamaParse response did not include a job id")

        deadline = time.time() + timeout_sec
        result_url = result_url_template.format(job_id=job_id)
        while True:
            if time.time() > deadline:
                raise TimeoutError("LlamaParse polling timed out")
            poll_response = requests.get(
                result_url,
                headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
                timeout=120,
            )
            if poll_response.status_code == 202:
                time.sleep(poll_interval_sec)
                continue
            poll_response.raise_for_status()
            result_payload = poll_response.json()
            return _canonicalize_ocr_payload(
                document_id=document_id,
                route=route,
                parser_engine=self.parser_engine,
                parser_version=self.parser_version,
                payload=result_payload,
                classifier_result=classifier_result,
                ocr_applied=True,
            )


class UnstructuredAdapter(BasePdfAdapter):
    parser_engine = "UNSTRUCTURED_API"
    parser_version = "v1"

    def parse(
        self,
        *,
        pdf_path: str,
        document_id: str,
        route: str,
        classifier_result: PdfClassifierResult,
    ) -> CanonicalDocument:
        api_url = str(getattr(settings, "UNSTRUCTURED_API_URL", "") or "").strip()
        api_key = str(getattr(settings, "UNSTRUCTURED_API_KEY", "") or "").strip()
        if not api_url:
            raise RuntimeError("UNSTRUCTURED_API_URL is required for OCR fallback")

        headers = {"Accept": "application/json"}
        if api_key:
            headers["unstructured-api-key"] = api_key

        with open(pdf_path, "rb") as handle:
            response = requests.post(
                api_url,
                headers=headers,
                data={
                    "strategy": "hi_res",
                    "languages": json.dumps(str(getattr(settings, "PDF_OCR_LANGUAGES", "tr,en")).split(",")),
                    "coordinates": "true",
                    "pdf_infer_table_structure": "true",
                },
                files={"files": (os.path.basename(pdf_path), handle, "application/pdf")},
                timeout=300,
            )
        response.raise_for_status()
        return _canonicalize_ocr_payload(
            document_id=document_id,
            route=route,
            parser_engine=self.parser_engine,
            parser_version=self.parser_version,
            payload=response.json(),
            classifier_result=classifier_result,
            ocr_applied=True,
        )


def _canonicalize_ocr_payload(
    *,
    document_id: str,
    route: str,
    parser_engine: str,
    parser_version: str,
    payload: Any,
    classifier_result: PdfClassifierResult,
    ocr_applied: bool,
) -> CanonicalDocument:
    blocks: List[CanonicalBlock] = []
    pages_map: Dict[int, CanonicalPage] = {
        int(page.page_number): CanonicalPage(
            page_number=int(page.page_number),
            has_text_layer=bool(page.has_text_layer),
            char_count=int(page.char_count),
            word_count=int(page.word_count),
            ocr_applied=ocr_applied,
            image_heavy_suspected=bool(page.image_heavy_suspected),
            garbled_ratio=float(page.garbled_ratio),
        )
        for page in classifier_result.pages
    }

    current_heading_path: List[str] = []
    reading_order = 0
    items = payload if isinstance(payload, list) else payload.get("items") or payload.get("blocks") or payload.get("pages") or []

    if isinstance(items, list):
        for idx, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            text = str(item.get("text") or item.get("content") or item.get("md") or "").strip()
            if not text:
                continue
            page_number = int(item.get("page_number") or item.get("page") or item.get("metadata", {}).get("page_number") or 1)
            block_type = str(item.get("block_type") or item.get("type") or _detect_block_type(text)).lower()
            if block_type == "heading":
                current_heading_path = [text]
            block = CanonicalBlock(
                block_id=f"{document_id}:ocr:{idx}",
                page_number=page_number,
                block_type=block_type,
                text=text,
                bbox=_normalize_bbox(item.get("bbox") or item.get("coordinates")),
                reading_order=reading_order,
                heading_path=list(current_heading_path),
                confidence=float(item.get("confidence") or item.get("metadata", {}).get("confidence") or 0.95),
                source_engine=parser_engine,
            )
            reading_order += 1
            blocks.append(block)
            if page_number not in pages_map:
                pages_map[page_number] = CanonicalPage(
                    page_number=page_number,
                    has_text_layer=False,
                    char_count=len(text),
                    word_count=len(text.split()),
                    ocr_applied=ocr_applied,
                    image_heavy_suspected=True,
                    garbled_ratio=0.0,
                )
            else:
                pages_map[page_number].ocr_applied = ocr_applied

    pages = sorted(pages_map.values(), key=lambda page: int(page.page_number))
    return build_document(
        document_id=document_id,
        route=route,
        parser_engine=parser_engine,
        parser_version=parser_version,
        pages=pages,
        blocks=blocks,
        classifier_metrics=classifier_result.classifier_metrics,
    )
